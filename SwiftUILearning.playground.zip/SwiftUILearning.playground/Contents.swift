import UIKit

var greeting = "Hello, playground"

//29 - Apr - 2026
//Today I am strating to learn the swiftui.

